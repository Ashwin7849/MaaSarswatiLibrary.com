# **App Name**: SeatWise

## Core Features:

- Seat Grid Display: Display available and booked seats in an interactive grid layout.
- Instant Seat Booking: Allow users to instantly book an available seat with a single click.
- Real-time Availability Updates: Show seat availability status (available/booked) in real-time.
- Booking tool: AI that reasons over and enforces single booking limitations.
- Simple User Login: Enable user login with only Name and Phone Number, and keep users in a browser session.
- My Booking Section: Display the user's booked seat information in a dedicated section.
- Seat Cancellation: Allow users to cancel their booked seat.

## Style Guidelines:

- Primary color: Light blue (#90CAF9), evoking calmness and focus.
- Background color: Very light blue (#E3F2FD), creating a soft, unobtrusive backdrop.
- Accent color: Pale violet (#B39DDB), drawing interest but remaining harmonious.
- Body and headline font: 'Inter' sans-serif font. Provides a modern, neutral aesthetic suitable for both headings and body text, and renders clearly.
- Use simple, clear icons to represent seat availability and booking status.
- Employ a responsive grid layout to display seats, ensuring optimal viewing on different devices.
- Use subtle animations (e.g., color change) to indicate booking and cancellation actions.