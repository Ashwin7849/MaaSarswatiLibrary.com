'use client';

import { useUser } from '@/hooks/useUser';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Card } from '@/components/ui/card';
import { useState } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useRouter } from 'next/navigation';
import type { Seat } from '@/lib/seats';

type BusLayoutProps = {
  selectedSeat: string | null;
  setSelectedSeat: (seatId: string | null) => void;
};

export function BusLayout({ selectedSeat, setSelectedSeat }: BusLayoutProps) {
  const { seats, bookSeat, user, userBooking } = useUser();
  const [bookingSeatId, setBookingSeatId] = useState<string | null>(null);
  const { toast } = useToast();
  const { t } = useLanguage();
  const router = useRouter();

  const handleSeatClick = (seatId: string) => {
    const seat = seats.find((s) => s.id === seatId);
    if (!seat) return;

    if (seat.userId === user?.id) {
      setSelectedSeat(seatId === selectedSeat ? null : seatId);
      return;
    }

    if (seat.status === 'booked' || seat.status === 'pending') {
      toast({
        variant: 'destructive',
        title: t.toasts.seatUnavailable,
        description: t.toasts.seatAlreadyBooked,
      });
      return;
    }

    if (seat.status === 'blocked') {
      toast({
        variant: 'destructive',
        title: t.toasts.seatUnavailable,
        description: t.toasts.seatUnderMaintenance,
      });
      return;
    }

    if (userBooking) {
      toast({
        variant: 'destructive',
        title: t.toasts.alreadyHaveBooking,
      });
      return;
    }
    setSelectedSeat(seatId === selectedSeat ? null : seatId);
  };

  const handleConfirmBooking = async () => {
    if (!selectedSeat) return;
    setBookingSeatId(selectedSeat);
    try {
      const newBooking = await bookSeat(selectedSeat);
      router.push(`/payment?seatId=${newBooking.id}`);
      setSelectedSeat(null);
    } catch (error) {
      toast({
        variant: 'destructive',
        title: t.toasts.error.title,
        description:
          error instanceof Error ? error.message : t.toasts.error.description,
      });
    } finally {
      setBookingSeatId(null);
    }
  };

  const renderSeats = (seatNumbers: number[]) => {
    return seatNumbers.map((seatNumber) => {
      const seat = seats.find((s) => s.number === seatNumber);
      if (!seat)
        return <div key={`placeholder-${seatNumber}`} className="h-12 w-12" />;

      const isAvailable = seat.status === 'available';
      const isBooked = seat.status === 'booked';
      const isPending = seat.status === 'pending';
      const isBlocked = seat.status === 'blocked';
      const isMyBooking = seat.userId === user?.id;
      const isBooking = bookingSeatId === seat.id;
      const isSelected = selectedSeat === seat.id;

      let seatColor = 'bg-green-500 text-white hover:bg-green-600';
      if (isMyBooking && !isSelected) seatColor = 'bg-primary text-primary-foreground';
      if (!isMyBooking && isAvailable) seatColor = 'bg-green-500 text-white hover:bg-green-600';
      if (isBooked) seatColor = 'bg-red-500 text-white cursor-not-allowed';
      if (isPending) seatColor = 'bg-yellow-400 text-white cursor-not-allowed';
      if (isBlocked) seatColor = 'bg-gray-500 text-white cursor-not-allowed';
      if (isSelected) seatColor = 'bg-orange-400 ring-2 ring-orange-600';

      return (
        <Button
          key={seat.id}
          variant="ghost"
          className={cn(
            'h-12 w-12 rounded-lg text-lg font-bold transition-all duration-200 transform hover:scale-110',
            seatColor,
            isBooking && 'animate-pulse'
          )}
          disabled={bookingSeatId !== null || (!isAvailable && !isMyBooking)}
          onClick={() => handleSeatClick(seat.id)}
          aria-label={`Seat ${seat.number}, ${seat.status}`}
        >
          {seat.number}
        </Button>
      );
    });
  };
  
    const seatToBook = seats.find(s => s.id === selectedSeat);

  return (
    <Card className="p-4 md:p-6 bg-white">
      <div className="flex justify-between items-start mb-4">
        <h3 className="font-bold text-lg font-headline">
          {t.busLayout.selectSeat}
        </h3>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        <div className="flex-grow">
          <div className="space-y-3">
            <div className="flex justify-between">
              {renderSeats([21, 22, 23, 24, 25])}
            </div>
            <div className="flex justify-between">
              {renderSeats([20, 19, 18, 17, 16])}
            </div>
            <div className="flex justify-between">
              {renderSeats([15, 14, 13, 12, 11])}
            </div>
            <div className="h-2"></div>
            <div className="flex justify-between">
              {renderSeats([10, 9, 8, 7, 6])}
            </div>
            <div className="flex justify-between">
              {renderSeats([5, 4, 3, 2, 1])}
            </div>
          </div>
        </div>
        <div className="w-full md:w-auto flex flex-col justify-between items-center relative">
          <div className="absolute -top-4 text-sm text-muted-foreground">
            {t.busLayout.specialSeats}
          </div>
          <div className="flex flex-row md:flex-col gap-2">
            {renderSeats([26, 27, 28, 29, 30])}
          </div>
        </div>
      </div>
      <div className="mt-6">
        <h3 className="text-center font-bold text-lg mb-4 font-headline">
          {t.busLayout.seatStatusTitle}
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 text-center">
          <div className="flex items-center justify-center space-x-2">
            <div className="h-4 w-4 rounded-full bg-green-500" />
            <span className="text-sm">
              {t.busLayout.status.available.hi} <br />(
              {t.busLayout.status.available.en})
            </span>
          </div>
          <div className="flex items-center justify-center space-x-2">
            <div className="h-4 w-4 rounded-full bg-red-500" />
            <span className="text-sm">
              {t.busLayout.status.booked.hi} <br />(
              {t.busLayout.status.booked.en})
            </span>
          </div>
          <div className="flex items-center justify-center space-x-2">
            <div className="h-4 w-4 rounded-full bg-yellow-400" />
            <span className="text-sm">
              Pending <br />
              (लंबित)
            </span>
          </div>
          <div className="flex items-center justify-center space-x-2">
            <div className="h-4 w-4 rounded-full bg-orange-400" />
            <span className="text-sm">
              {t.busLayout.status.selected.hi} <br />(
              {t.busLayout.status.selected.en})
            </span>
          </div>
          <div className="flex items-center justify-center space-x-2">
            <div className="h-4 w-4 rounded-full bg-primary" />
            <span className="text-sm">
              {t.busLayout.status.yourSeat.hi} <br />(
              {t.busLayout.status.yourSeat.en})
            </span>
          </div>
        </div>
      </div>
       {selectedSeat && (!userBooking || userBooking?.id === selectedSeat) && (
        <div className="mt-6 text-center">
         <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button size="lg" className="font-bold">
                 {t.busLayout.confirmBooking.replace('{seatNumber}', seatToBook?.number?.toString() || '')}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Proceed to Payment?</AlertDialogTitle>
                <AlertDialogDescription>
                  You are about to book seat {seatToBook?.number}. You will be redirected to the payment page to complete your booking for ₹500.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleConfirmBooking}>
                  Proceed
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      )}
    </Card>
  );
}
