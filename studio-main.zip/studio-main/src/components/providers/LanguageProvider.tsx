
'use client';

import {
  createContext,
  useState,
  useEffect,
  type ReactNode,
  useCallback,
  useMemo,
} from 'react';
import { translations, type Language, type Translations } from '@/lib/translations';

type LanguageContextType = {
  language: Language;
  t: Translations[Language];
  setLanguage: (language: Language) => void;
};

export const LanguageContext = createContext<LanguageContextType | undefined>(
  undefined
);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('hi');
  const [hasMounted, setHasMounted] = useState(false);

  useEffect(() => {
    const savedLang = localStorage.getItem('seatwise_language') as Language | null;
    if (savedLang && translations[savedLang]) {
      setLanguage(savedLang);
    }
    setHasMounted(true);
  }, []);


  const handleSetLanguage = useCallback((lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('seatwise_language', lang);
  }, []);

  const t = useMemo(() => translations[language], [language]);

  const value = useMemo(
    () => ({
      language,
      t,
      setLanguage: handleSetLanguage,
    }),
    [language, t, handleSetLanguage]
  );
  
  if (!hasMounted) {
    return (
      <LanguageContext.Provider value={value}>
        {null}
      </LanguageContext.Provider>
    )
  }

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}
