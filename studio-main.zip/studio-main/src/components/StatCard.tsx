
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { cn } from '@/lib/utils';
import type { ReactNode } from 'react';

type StatCardProps = {
  title: string;
  value: string | number;
  icon: ReactNode;
  description: string;
  variant?: 'default' | 'success' | 'danger' | 'warning';
};

export function StatCard({ title, value, icon, description, variant = 'default' }: StatCardProps) {
  const variantClasses = {
    default: '',
    success: 'bg-green-100 dark:bg-green-900/30 border-green-200 dark:border-green-800',
    danger: 'bg-red-100 dark:bg-red-900/30 border-red-200 dark:border-red-800',
    warning: 'bg-yellow-100 dark:bg-yellow-900/30 border-yellow-200 dark:border-yellow-800'
  }
  const iconVariantClasses = {
    default: 'text-primary',
    success: 'text-green-600 dark:text-green-400',
    danger: 'text-red-600 dark:text-red-400',
    warning: 'text-yellow-600 dark:text-yellow-400'
  }

  return (
    <Card className={cn(variantClasses[variant])}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex items-center gap-2">
           <div className={cn("p-1.5 bg-background rounded-md", iconVariantClasses[variant])}>{icon}</div>
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        <div className={cn("text-2xl font-bold", iconVariantClasses[variant])}>{value}</div>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
}
