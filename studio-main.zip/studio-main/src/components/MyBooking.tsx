'use client';

import { useUser } from '@/hooks/useUser';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Armchair, Calendar, Clock, Info, AlertTriangle, MessageSquare } from 'lucide-react';
import Link from 'next/link';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useLanguage } from '@/hooks/useLanguage';
import { Badge } from '@/components/ui/badge';

export function MyBooking() {
  const { userBooking, cancelBooking, isLoading } = useUser();
  const { toast } = useToast();
  const { t } = useLanguage();

  const handleCancel = () => {
    if (userBooking) {
      cancelBooking(userBooking.id);
      toast({
        title: t.toasts.bookingCancelled.title,
        description: t.toasts.bookingCancelled.description,
      });
    }
  };

  if (isLoading) {
    return (
      <Card className="w-full md:max-w-md">
        <CardHeader>
          <CardTitle>{t.myBooking.loading}</CardTitle>
        </CardHeader>
      </Card>
    );
  }

  if (!userBooking) {
    return (
      <Card className="w-full md:max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Info className="text-primary" /> {t.myBooking.noBooking.title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            {t.myBooking.noBooking.description}
          </p>
        </CardContent>
        <CardFooter>
          <Link href="/booking">
            <Button>{t.myBooking.noBooking.button}</Button>
          </Link>
        </CardFooter>
      </Card>
    );
  }
  
  const bookingDate = userBooking.bookingDate
    ? new Date(userBooking.bookingDate)
    : null;
  const expiryDate = bookingDate
    ? new Date(bookingDate.getTime() + 31 * 24 * 60 * 60 * 1000)
    : null;
  
  const isPending = userBooking.status === 'pending';
  const isRejected = userBooking.payment?.status === 'rejected';

  return (
    <Card className="w-full md:max-w-md shadow-lg">
      <CardHeader>
        <CardTitle className="font-headline flex justify-between items-center">
          <span>{t.myBooking.bookedSeat.title}</span>
          {userBooking.status === 'booked' && <Badge variant="default" className="bg-green-500">Confirmed</Badge>}
          {userBooking.status === 'pending' && <Badge variant="secondary" className="bg-yellow-500">Pending</Badge>}
        </CardTitle>
        <CardDescription>{t.myBooking.bookedSeat.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center space-x-4 rounded-md border p-4">
          <Armchair className="h-10 w-10 text-primary" />
          <div className="flex-1 space-y-1">
            <p className="text-lg font-semibold">
              {t.myBooking.bookedSeat.seatLocation
                .replace('{row}', userBooking.row)
                .replace('{number}', userBooking.number.toString())}
            </p>
            <p className="text-sm text-muted-foreground">
              {t.myBooking.bookedSeat.studySpot}
            </p>
          </div>
        </div>

        {isPending && !isRejected && (
           <div className="flex items-start text-sm text-yellow-600 bg-yellow-50 p-3 rounded-md border border-yellow-200">
             <AlertTriangle className="mr-2 h-4 w-4 mt-0.5" />
             <span>Awaiting payment verification. Please complete the payment if you haven't.</span>
           </div>
        )}

        {isRejected && (
           <div className="flex items-start text-sm text-red-600 bg-red-50 p-3 rounded-md border border-red-200">
             <MessageSquare className="mr-2 h-4 w-4 mt-0.5 shrink-0" />
             <div>
                <span className="font-bold">Admin Comment:</span>{' '}
                {userBooking.payment?.adminComment || "Your payment was rejected."}
             </div>
           </div>
        )}

        {bookingDate && (
          <div className="flex items-center text-sm text-muted-foreground">
            <Calendar className="mr-2 h-4 w-4" />
            <span>
              {t.myBooking.bookedSeat.bookedOn}: {bookingDate.toLocaleString()}
            </span>
          </div>
        )}
        {expiryDate && !isPending && (
          <div className="flex items-center text-sm text-muted-foreground">
            <Clock className="mr-2 h-4 w-4" />
            <span>
              {t.myBooking.bookedSeat.expiresOn}: {expiryDate.toLocaleDateString()}
            </span>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex flex-col gap-2">
         {isPending && (
           <Link href={`/payment?seatId=${userBooking.id}`} className="w-full">
            <Button className="w-full">Complete Payment</Button>
           </Link>
         )}
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="destructive" className="w-full">
              {t.myBooking.cancelBookingButton}
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>{t.myBooking.cancelDialog.title}</AlertDialogTitle>
              <AlertDialogDescription>
                {t.myBooking.cancelDialog.description}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>
                {t.myBooking.cancelDialog.keepButton}
              </AlertDialogCancel>
              <AlertDialogAction onClick={handleCancel}>
                {t.myBooking.cancelDialog.confirmButton}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardFooter>
    </Card>
  );
}
