'use client';

import { AdminShell } from './shell';

export function AdminWrapper({ children }: { children: React.ReactNode }) {
  return <AdminShell>{children}</AdminShell>;
}
