
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useUser } from '@/hooks/useUser';
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import { AdminWrapper } from '../admin-wrapper';

export default function UserManagementPage() {
  const { users, seats } = useUser();

  const getBookingHistory = (userId: string) => {
    const userSeats = seats.filter(s => s.userId === userId);
    if(userSeats.length === 0) return 'No booking history';
    return userSeats.map(s => `Seat ${s.number}`).join(', ');
  }

  return (
    <AdminWrapper>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold font-headline">User Management</h1>
          <p className="text-muted-foreground">
            View and manage library members.
          </p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>All Users</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Booking History</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map(user => {
                  return (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.phone}</TableCell>
                      <TableCell>
                        {getBookingHistory(user.id)}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </AdminWrapper>
  );
}
