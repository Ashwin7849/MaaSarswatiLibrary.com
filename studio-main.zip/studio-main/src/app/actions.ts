'use server';

import {
  enforceSingleBooking,
  type EnforceSingleBookingInput,
} from '@/ai/flows/enforce-single-booking';

export async function checkBookingPermission(input: EnforceSingleBookingInput) {
  try {
    const result = await enforceSingleBooking(input);
    return { success: true, data: result };
  } catch (error) {
    console.error('AI check failed:', error);
    // In case of AI failure, default to allowing the booking if they don't have one.
    if (!input.hasExistingBooking) {
      return {
        success: true,
        data: {
          allowedToBook: true,
          message:
            'Booking eligibility confirmed (AI check bypassed).',
        },
      };
    }
    // Deny if they already have a booking, even if AI fails.
    return {
      success: false,
      error: 'A system error occurred. Please try again.',
      data: {
        allowedToBook: false,
        message: 'Could not verify booking eligibility at this time.',
      },
    };
  }
}
