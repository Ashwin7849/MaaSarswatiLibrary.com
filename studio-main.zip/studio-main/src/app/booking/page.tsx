'use client';

import Link from 'next/link';
import { BusLayout } from '@/components/BusLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useUser } from '@/hooks/useUser';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Home, User } from 'lucide-react';
import { MyBooking } from '@/components/MyBooking';
import { StatCard } from '@/components/StatCard';
import { Armchair, User as UserIcon } from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '@/hooks/useLanguage';

export default function BookingPage() {
  const { user, isLoading, seatStats } = useUser();
  const [selectedSeat, setSelectedSeat] = useState<string | null>(null);
  const { t } = useLanguage();

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Skeleton className="h-12 w-1/4 mb-4" />
        <Skeleton className="h-8 w-1/2 mb-8" />
        <div className="grid grid-cols-5 md:grid-cols-10 gap-2 md:gap-4">
          {Array.from({ length: 50 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-12 rounded-md" />
          ))}
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="container mx-auto flex h-[calc(100vh-200px)] items-center justify-center px-4 py-8">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <CardTitle>{t.booking.pleaseLogIn}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-muted-foreground">
              {t.booking.logInToBook}
            </p>
            <Link href="/login?redirect=/booking">
              <Button>{t.booking.goToLogin}</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="bg-primary/10">
      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="home">
          <TabsList className="grid w-full grid-cols-2 bg-primary/20">
            <TabsTrigger value="home">
              <Home className="mr-2" />
              {t.header.home}
            </TabsTrigger>
            <TabsTrigger value="bookings">
              <User className="mr-2" />
              {t.header.myBooking}
            </TabsTrigger>
          </TabsList>
          <TabsContent value="home">
            <div className="grid grid-cols-2 gap-4 my-4">
              <StatCard
                title={t.booking.totalSeatsCard.title}
                value={seatStats.total}
                description={t.booking.totalSeatsCard.description}
                icon={<Armchair className="text-primary" />}
              />
              <StatCard
                title={t.booking.selectedCard.title}
                value={selectedSeat ? 1 : 0}
                description={t.booking.selectedCard.description}
                icon={<UserIcon className="text-orange-500" />}
              />
            </div>
            <BusLayout selectedSeat={selectedSeat} setSelectedSeat={setSelectedSeat} />
          </TabsContent>
          <TabsContent value="bookings" className="flex justify-center items-center pt-8">
            <MyBooking />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
