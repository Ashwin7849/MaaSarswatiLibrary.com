
'use client';

import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useUser } from '@/hooks/useUser';
import { useRouter } from 'next/navigation';
import { Logo } from '@/components/Logo';
import Link from 'next/link';
import { useLanguage } from '@/hooks/useLanguage';
import { useToast } from '@/hooks/use-toast';
import { useSettings } from '@/hooks/useSettings';

const formSchema = z.object({
  username: z.string().min(2, {
    message: 'Username must be at least 2 characters.',
  }),
  phone: z.string().min(10, {
    message: 'Phone number must be at least 10 digits.',
  }),
});

export default function RegisterPage() {
  const { registerUser } = useUser();
  const { settings } = useSettings();
  const router = useRouter();
  const { t } = useLanguage();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: '',
      phone: '',
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    try {
      registerUser(values.username, values.phone);
      router.push('/login');
    } catch (error) {
       if (error instanceof Error) {
        toast({
          variant: 'destructive',
          title: 'Registration Failed',
          description: error.message,
        });
      }
    }
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-gray-100 dark:bg-gray-900">
      <div className="w-full max-w-sm">
        <div className="rounded-t-lg bg-gradient-to-b from-blue-500 to-blue-600 p-8 text-center text-white">
          <div className="mx-auto mb-4 flex h-24 w-24 items-center justify-center">
             {settings.logo ? (
              <img src={settings.logo} alt={t.login.logoAlt} className="h-24 w-24 rounded-full" />
            ) : (
              <Logo className="h-24 w-24" />
            )}
          </div>
          <h1 className="text-2xl font-bold font-headline">Create Account</h1>
          <p className="text-sm">Join {settings.libraryName}</p>
        </div>
        <div className="rounded-b-lg bg-white dark:bg-gray-800 p-8 shadow-md">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input
                        placeholder={t.login.usernamePlaceholder}
                        className="rounded-full"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input
                        type="tel"
                        placeholder={t.login.phonePlaceholder}
                        className="rounded-full"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button
                type="submit"
                className="w-full rounded-full bg-gradient-to-r from-blue-500 to-blue-600 font-bold text-white hover:opacity-90"
              >
                Register
              </Button>
            </form>
          </Form>
          <div className="mt-4 text-center">
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Already have an account?{' '}
              <Link href="/login" className="font-bold text-blue-500">
                Login
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
