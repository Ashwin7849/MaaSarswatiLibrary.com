
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUser } from '@/hooks/useUser';

export default function Home() {
  const { user } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (user) {
      if(user.role === 'admin') {
        router.push('/admin/dashboard');
      } else {
        router.push('/booking');
      }
    } else {
      router.push('/login');
    }
  }, [user, router]);

  return null; // or a loading spinner
}
