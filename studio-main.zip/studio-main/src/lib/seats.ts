export type Seat = {
  id: string;
  row: string;
  number: number;
  status: 'available' | 'booked' | 'blocked' | 'pending';
  userId: string | null;
  bookingDate: number | null;
  payment?: {
    status: 'pending_verification' | 'verified' | 'rejected';
    screenshotPath?: string;
    transactionId?: string;
    uploadedAt?: number;
    adminComment?: string;
  };
};

// As per the image, there are 30 seats.
const TOTAL_SEATS = 30;

export const initialSeats: Seat[] = Array.from({ length: TOTAL_SEATS }, (_, i) => {
  const seatNumber = i + 1;
  return {
    id: `${seatNumber}`,
    row: String.fromCharCode(65 + Math.floor(i / 5)), // Example row logic, can be adjusted
    number: seatNumber,
    status: 'available',
    userId: null,
    bookingDate: null,
  };
});
