import { config } from 'dotenv';
config();

import '@/ai/flows/enforce-single-booking.ts';