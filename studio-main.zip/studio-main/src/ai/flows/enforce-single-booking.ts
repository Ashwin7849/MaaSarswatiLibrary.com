'use server';
/**
 * @fileOverview AI flow to enforce the single booking limitation.
 *
 * - enforceSingleBooking - A function that checks and enforces single booking.
 * - EnforceSingleBookingInput - The input type for the enforceSingleBooking function.
 * - EnforceSingleBookingOutput - The return type for the enforceSingleBooking function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const EnforceSingleBookingInputSchema = z.object({
  userId: z.string().describe('The ID of the user.'),
  seatId: z.string().describe('The ID of the seat being booked.'),
  hasExistingBooking: z
    .boolean()
    .describe('Whether the user already has a booking.'),
});
export type EnforceSingleBookingInput = z.infer<
  typeof EnforceSingleBookingInputSchema
>;

const EnforceSingleBookingOutputSchema = z.object({
  allowedToBook: z
    .boolean()
    .describe(
      'Whether the user is allowed to book the seat based on the single booking rule.'
    ),
  message: z
    .string()
    .describe(
      'A message explaining whether the booking is allowed or why it is not.'
    ),
});
export type EnforceSingleBookingOutput = z.infer<
  typeof EnforceSingleBookingOutputSchema
>;

export async function enforceSingleBooking(
  input: EnforceSingleBookingInput
): Promise<EnforceSingleBookingOutput> {
  return enforceSingleBookingFlow(input);
}

const prompt = ai.definePrompt({
  name: 'enforceSingleBookingPrompt',
  input: {schema: EnforceSingleBookingInputSchema},
  output: {schema: EnforceSingleBookingOutputSchema},
  prompt: `You are a booking assistant for a library seating system. Your one and only rule is that a user can only have one seat booked at a time.

- User ID: {{{userId}}}
- Seat ID they want to book: {{{seatId}}}
- Do they already have a booking? {{{hasExistingBooking}}}

Your task is to decide if the user is allowed to book the new seat based *only* on the 'hasExistingBooking' flag.

- If 'hasExistingBooking' is true, they are NOT allowed to book. Set 'allowedToBook' to false and provide a message in Hindi explaining that they already have a booking.
- If 'hasExistingBooking' is false, they ARE allowed to book. Set 'allowedToBook' to true and provide a success message in Hindi.

Do not add any other logic or considerations.
`,
});

const enforceSingleBookingFlow = ai.defineFlow(
  {
    name: 'enforceSingleBookingFlow',
    inputSchema: EnforceSingleBookingInputSchema,
    outputSchema: EnforceSingleBookingOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
