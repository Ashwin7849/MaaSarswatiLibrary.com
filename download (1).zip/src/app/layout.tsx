
import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from '@/components/ui/toaster';
import { Header } from '@/components/Header';
import { UserProvider } from '@/components/providers/UserProvider';
import { cn } from '@/lib/utils';
import { LanguageProvider } from '@/components/providers/LanguageProvider';
import { SettingsProvider } from '@/components/providers/SettingsProvider';

export const metadata: Metadata = {
  title: 'Maa Sarswati Library',
  description: 'Read Today, Lead Tomorrow.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Tiro+Devanagari+Hindi:ital@0;1&display=swap"
          rel="stylesheet"
        />
      </head>
      <body
        className={cn(
          'min-h-screen bg-background font-body antialiased',
          'font-body'
        )}
      >
        <SettingsProvider>
          <LanguageProvider>
            <UserProvider>
              <div className="relative flex min-h-screen flex-col">
                <Header />
                <main className="flex-1">{children}</main>
              </div>
              <Toaster />
            </UserProvider>
          </LanguageProvider>
        </SettingsProvider>
      </body>
    </html>
  );
}
