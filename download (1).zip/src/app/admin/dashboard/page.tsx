
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUser } from '@/hooks/useUser';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { StatCard } from '@/components/StatCard';
import { Armchair, Bookmark, CheckCircle, UserX, Users, CalendarCheck, Percent, ShieldAlert } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { startOfToday } from 'date-fns';
import { AdminWrapper } from '../admin-wrapper';

export default function AdminDashboardPage() {
  const { user, isLoading, seats, cancelBooking, users, seatStats } = useUser();
  const router = useRouter();
  const { toast } = useToast();

  useEffect(() => {
    if (!isLoading && user?.role !== 'admin') {
      router.push('/login?redirect=/admin/dashboard');
    }
  }, [user, isLoading, router]);

  const handleCancelBooking = (seatId: string) => {
    cancelBooking(seatId);
    toast({
      title: 'Booking Cancelled',
      description: 'The seat has been made available.',
    });
  };

  if (isLoading || !user) {
    return (
      <AdminWrapper>
        <div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
            <Skeleton className="h-28" />
            <Skeleton className="h-28" />
            <Skeleton className="h-28" />
            <Skeleton className="h-28" />
          </div>
          <Skeleton className="h-96 w-full" />
        </div>
      </AdminWrapper>
    );
  }

  if (user.role !== 'admin') {
    return (
      <AdminWrapper>
        <div className="container mx-auto flex h-screen items-center justify-center">
          <Card className="w-full max-w-md text-center">
            <CardHeader>
              <CardTitle>Access Denied</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                You do not have permission to view this page.
              </p>
              <Link href="/login?redirect=/admin/dashboard">
                <Button>Login as Admin</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </AdminWrapper>
    );
  }

  const bookedSeats = seats.filter(seat => seat.status === 'booked');
  const todaysBookings = bookedSeats.filter(seat => {
    if (!seat.bookingDate) return false;
    const bookingDay = new Date(seat.bookingDate);
    return bookingDay >= startOfToday();
  });

  const getUserInfo = (userId: string | null) => {
    if (!userId) return { name: 'Unknown', phone: 'N/A' };
    const bookingUser = users.find(u => u.id === userId);
    return {
      name: bookingUser?.name || 'Unknown User',
      phone: bookingUser?.phone || 'N/A',
    };
  };
  
  const usagePercentage = seatStats.total > 0 
    ? ((seatStats.booked / seatStats.total) * 100).toFixed(0)
    : 0;

  return (
    <AdminWrapper>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold font-headline">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back, {user.name}. Here's an overview of your library.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          <StatCard
            title="Total Seats"
            value={seatStats.total}
            icon={<Armchair />}
            description="Total capacity of the library."
          />
          <StatCard
            title="Available Seats"
            value={seatStats.available}
            icon={<CheckCircle />}
            description="Seats currently open for booking."
            variant="success"
          />
          <StatCard
            title="Booked Seats"
            value={seatStats.booked}
            icon={<Bookmark />}
            description="Seats that are currently occupied."
            variant="danger"
          />
          <StatCard
            title="Maintenance"
            value={seatStats.blocked}
            icon={<ShieldAlert />}
            description="Seats under maintenance."
            variant="warning"
          />
          <StatCard
            title="Total Users"
            value={users.length}
            icon={<Users />}
            description="Total registered members."
          />
          <StatCard
            title="Today's Bookings"
            value={todaysBookings.length}
            icon={<CalendarCheck />}
            description="New bookings made today."
          />
          <StatCard
            title="Average Usage"
            value={`${usagePercentage}%`}
            icon={<Percent />}
            description="Percentage of seats booked."
          />
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recent Bookings</CardTitle>
            <p className="text-sm text-muted-foreground">
              A view of the most recent seat reservations.
            </p>
          </CardHeader>
          <CardContent>
            {bookedSeats.length > 0 ? (
              <div className="w-full overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Seat</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Booked By</TableHead>
                      <TableHead>Phone No.</TableHead>
                      <TableHead>Booking Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {bookedSeats.slice(0, 5).map(seat => {
                      const userInfo = getUserInfo(seat.userId);
                      const bookingDate = seat.bookingDate
                        ? new Date(seat.bookingDate)
                        : null;
                      return (
                        <TableRow key={seat.id}>
                          <TableCell className="font-medium">
                            {seat.number}
                          </TableCell>
                          <TableCell>
                            <Badge variant="destructive">Booked</Badge>
                          </TableCell>
                          <TableCell>{userInfo.name}</TableCell>
                          <TableCell>{userInfo.phone}</TableCell>
                          <TableCell>
                            {bookingDate ? bookingDate.toLocaleString() : 'N/A'}
                          </TableCell>
                          <TableCell className="text-right">
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="destructive" size="sm">
                                  <UserX className="mr-2 h-4 w-4" />
                                  Cancel
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>
                                    Cancel booking for Seat {seat.number}?
                                  </AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This action will cancel the booking for{' '}
                                    {userInfo.name} and make the seat available.
                                    This cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Back</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => handleCancelBooking(seat.id)}
                                  >
                                    Confirm Cancellation
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <p className="py-8 text-center text-muted-foreground">
                No seats are currently booked.
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminWrapper>
  );
}
