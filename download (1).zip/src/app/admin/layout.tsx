import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Admin Panel - Maa Saraswati Library',
  description: 'Admin panel for managing the library.',
};

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
}
