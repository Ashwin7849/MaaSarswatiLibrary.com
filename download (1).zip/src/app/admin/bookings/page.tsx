
'use client';

import { useState, useMemo } from 'react';
import { useUser } from '@/hooks/useUser';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { UserX, ArrowUpDown } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import type { Seat } from '@/lib/seats';
import { AdminWrapper } from '../admin-wrapper';

export default function AllBookingsPage() {
  const { seats, cancelBooking, users } = useUser();
  const { toast } = useToast();
  const [filter, setFilter] = useState('');
  const [sortConfig, setSortConfig] = useState<{
    key: keyof Seat | 'userName' | 'userPhone';
    direction: 'ascending' | 'descending';
  } | null>({ key: 'bookingDate', direction: 'descending' });

  const bookedSeats = useMemo(
    () => seats.filter(seat => seat.status === 'booked'),
    [seats]
  );

  const getUserInfo = (userId: string | null) => {
    if (!userId) return { name: 'Unknown', phone: 'N/A' };
    const bookingUser = users.find(u => u.id === userId);
    return {
      name: bookingUser?.name || 'Unknown User',
      phone: bookingUser?.phone || 'N/A',
    };
  };
  
  const sortedAndFilteredBookings = useMemo(() => {
    let sortableItems = [...bookedSeats];

    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        const aUserInfo = getUserInfo(a.userId);
        const bUserInfo = getUserInfo(b.userId);

        const aValue = sortConfig.key === 'userName' ? aUserInfo.name : sortConfig.key === 'userPhone' ? aUserInfo.phone : a[sortConfig.key];
        const bValue = sortConfig.key === 'userName' ? bUserInfo.name : sortConfig.key === 'userPhone' ? bUserInfo.phone : b[sortConfig.key];
        
        if (aValue === null || bValue === null) return 0;
        if (aValue < bValue) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }
    
    return sortableItems.filter(seat => {
      const userInfo = getUserInfo(seat.userId);
      const searchTerm = filter.toLowerCase();
      return (
        seat.number.toString().includes(searchTerm) ||
        userInfo.name.toLowerCase().includes(searchTerm) ||
        userInfo.phone.toLowerCase().includes(searchTerm)
      )
    });

  }, [bookedSeats, filter, sortConfig, users]);

  const requestSort = (key: keyof Seat | 'userName' | 'userPhone') => {
    let direction: 'ascending' | 'descending' = 'ascending';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };


  const handleCancelBooking = (seatId: string) => {
    cancelBooking(seatId);
    toast({
      title: 'Booking Cancelled',
      description: 'The seat has been made available.',
    });
  };

  const getSortIcon = (key: keyof Seat | 'userName' | 'userPhone') => {
    if (!sortConfig || sortConfig.key !== key) {
      return <ArrowUpDown className="ml-2 h-4 w-4 opacity-50" />;
    }
    return sortConfig.direction === 'ascending' ? '▲' : '▼';
  };

  return (
    <AdminWrapper>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold font-headline">All Bookings</h1>
          <p className="text-muted-foreground">
            View and manage all current reservations.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Current Bookings</CardTitle>
            <CardDescription>
              A complete list of all seats that are currently booked.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <Input 
                placeholder="Filter by seat, name, or phone..."
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="max-w-sm"
              />
            </div>
            {sortedAndFilteredBookings.length > 0 ? (
              <div className="w-full overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead onClick={() => requestSort('number')}>
                        <div className="flex items-center cursor-pointer">
                          Seat {getSortIcon('number')}
                        </div>
                      </TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead onClick={() => requestSort('userName')}>
                        <div className="flex items-center cursor-pointer">
                          Booked By {getSortIcon('userName')}
                        </div>
                      </TableHead>
                      <TableHead onClick={() => requestSort('userPhone')}>
                        <div className="flex items-center cursor-pointer">
                          Phone No. {getSortIcon('userPhone')}
                        </div>
                      </TableHead>
                      <TableHead onClick={() => requestSort('bookingDate')}>
                        <div className="flex items-center cursor-pointer">
                          Booking Date {getSortIcon('bookingDate')}
                        </div>
                      </TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedAndFilteredBookings.map(seat => {
                      const userInfo = getUserInfo(seat.userId);
                      const bookingDate = seat.bookingDate
                        ? new Date(seat.bookingDate)
                        : null;
                      return (
                        <TableRow key={seat.id}>
                          <TableCell className="font-medium">
                            {seat.number}
                          </TableCell>
                          <TableCell>
                            <Badge variant="destructive">Booked</Badge>
                          </TableCell>
                          <TableCell>{userInfo.name}</TableCell>
                          <TableCell>{userInfo.phone}</TableCell>
                          <TableCell>
                            {bookingDate ? bookingDate.toLocaleString() : 'N/A'}
                          </TableCell>
                          <TableCell className="text-right">
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button variant="destructive" size="sm">
                                  <UserX className="mr-2 h-4 w-4" />
                                  Cancel
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>
                                    Cancel booking for Seat {seat.number}?
                                  </AlertDialogTitle>
                                  <AlertDialogDescription>
                                    This action will cancel the booking for{' '}
                                    {userInfo.name} and make the seat available.
                                    This cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Back</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => handleCancelBooking(seat.id)}
                                  >
                                    Confirm Cancellation
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <p className="py-8 text-center text-muted-foreground">
                {bookedSeats.length > 0 ? 'No bookings match your filter.' : 'No seats are currently booked.'}
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminWrapper>
  );
}
