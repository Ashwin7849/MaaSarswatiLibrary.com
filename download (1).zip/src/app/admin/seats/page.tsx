
'use client';
import { useState } from 'react';
import { useUser } from '@/hooks/useUser';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import type { Seat } from '@/lib/seats';
import { useToast } from '@/hooks/use-toast';
import { Pencil } from 'lucide-react';
import { AdminWrapper } from '../admin-wrapper';

export default function SeatManagementPage() {
  const { seats, updateSeatStatus } = useUser();
  const { toast } = useToast();

  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedSeat, setSelectedSeat] = useState<Seat | null>(null);
  const [newStatus, setNewStatus] = useState<Seat['status'] | ''>('');

  const handleEditClick = (seat: Seat) => {
    setSelectedSeat(seat);
    setNewStatus(seat.status);
    setIsEditDialogOpen(true);
  };

  const handleSaveChanges = () => {
    if (selectedSeat && newStatus) {
      updateSeatStatus(selectedSeat.id, newStatus as Seat['status']);
      toast({
        title: 'Seat Updated',
        description: `Seat ${selectedSeat.number} status has been changed to ${newStatus}.`,
      });
      setIsEditDialogOpen(false);
      setSelectedSeat(null);
      setNewStatus('');
    }
  };

  const getStatusBadge = (status: Seat['status']) => {
    switch (status) {
      case 'available':
        return <Badge variant="default" className="bg-green-500">Available</Badge>;
      case 'booked':
        return <Badge variant="destructive">Booked</Badge>;
      case 'blocked':
        return <Badge variant="secondary" className="bg-yellow-500">Maintenance</Badge>;
       case 'pending':
        return <Badge variant="secondary" className="bg-orange-500">Pending</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <AdminWrapper>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold font-headline">Seat Management</h1>
          <p className="text-muted-foreground">
            View and manage the status of all seats in the library.
          </p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>All Seats</CardTitle>
            <CardDescription>
              Click 'Edit' to change a seat's status.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="w-full overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Seat ID</TableHead>
                    <TableHead>Row</TableHead>
                    <TableHead>Number</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {seats
                    .sort((a, b) => a.number - b.number)
                    .map(seat => (
                      <TableRow key={seat.id}>
                        <TableCell className="font-mono">{seat.id}</TableCell>
                        <TableCell>{seat.row}</TableCell>
                        <TableCell>{seat.number}</TableCell>
                        <TableCell>{getStatusBadge(seat.status)}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEditClick(seat)}
                          >
                            <Pencil className="mr-2 h-4 w-4" />
                            Edit
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Seat {selectedSeat?.number}</DialogTitle>
              <DialogDescription>
                Change the status of this seat. This will update its availability
                in real-time.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <Select
                value={newStatus}
                onValueChange={value => setNewStatus(value as Seat['status'])}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a new status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">Available</SelectItem>
                  <SelectItem value="booked">Booked</SelectItem>
                   <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="blocked">Maintenance</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsEditDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button onClick={handleSaveChanges}>Save Changes</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminWrapper>
  );
}
