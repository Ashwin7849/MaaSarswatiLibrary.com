
'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { AdminWrapper } from '../admin-wrapper';
import { useSettings } from '@/hooks/useSettings';
import type { Settings } from '@/components/providers/SettingsProvider';

export default function SettingsPage() {
  const { settings, saveSettings, isLoading } = useSettings();
  const { toast } = useToast();

  const [localSettings, setLocalSettings] = useState<Settings>(settings);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [qrCodePreview, setQrCodePreview] = useState<string | null>(null);

  useEffect(() => {
    if (!isLoading) {
      setLocalSettings(settings);
      setLogoPreview(settings.logo);
      setQrCodePreview(settings.qrCode);
    }
  }, [settings, isLoading]);

  const handleInputChange = (field: keyof Settings, value: string | number) => {
    setLocalSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleLibraryDetailsSave = () => {
    saveSettings({
      libraryName: localSettings.libraryName,
      logo: logoPreview,
    });
    toast({
      title: 'Settings Saved',
      description: 'The library details have been updated.',
    });
  };

  const handlePaymentSettingsSave = () => {
    saveSettings({
      upiId: localSettings.upiId,
      qrCode: qrCodePreview,
    });
    toast({
      title: 'Payment Settings Saved',
      description: 'UPI ID and QR code have been updated.',
    });
  };

  const handleExpirySave = () => {
    saveSettings({ expiryDays: Number(localSettings.expiryDays) });
    toast({
      title: 'Expiry Set',
      description: `Bookings will now expire after ${localSettings.expiryDays} days.`,
    });
  };

  const handleFileUpload = (
    event: React.ChangeEvent<HTMLInputElement>,
    setter: (dataUrl: string | null) => void
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const dataUrl = reader.result as string;
        setter(dataUrl);
      };
      reader.readAsDataURL(file);
    } else {
      setter(null);
    }
  };

  if (isLoading) {
    return (
      <AdminWrapper>
        <div>Loading settings...</div>
      </AdminWrapper>
    );
  }

  return (
    <AdminWrapper>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold font-headline">Library Settings</h1>
          <p className="text-muted-foreground">
            Manage general library settings.
          </p>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Library Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="libraryName">Library Name</Label>
              <Input
                id="libraryName"
                value={localSettings.libraryName}
                onChange={e => handleInputChange('libraryName', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="logoUpload">Change Logo</Label>
              <Input
                id="logoUpload"
                type="file"
                accept="image/*"
                onChange={e => handleFileUpload(e, setLogoPreview)}
              />
            </div>
            {logoPreview && (
              <div className="space-y-2">
                <Label>Logo Preview</Label>
                <img
                  src={logoPreview}
                  alt="Logo Preview"
                  className="h-24 w-24 rounded-full border p-2"
                />
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button onClick={handleLibraryDetailsSave}>Save Details</Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Payment Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="upiId">UPI ID</Label>
              <Input
                id="upiId"
                placeholder="your-upi-id@okhdfcbank"
                value={localSettings.upiId}
                onChange={e => handleInputChange('upiId', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="qrCodeUpload">QR Code Image</Label>
              <Input
                id="qrCodeUpload"
                type="file"
                accept="image/*"
                onChange={e => handleFileUpload(e, setQrCodePreview)}
              />
            </div>
            {qrCodePreview && (
              <div className="space-y-2">
                <Label>QR Code Preview</Label>
                <img
                  src={qrCodePreview}
                  alt="QR Code Preview"
                  className="h-32 w-32 rounded-md border p-2"
                />
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button onClick={handlePaymentSettingsSave}>
              Save Payment Settings
            </Button>
          </CardFooter>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Booking Expiry</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="expiryHours">Expiry Time (in Days)</Label>
              <Input
                id="expiryHours"
                type="number"
                value={localSettings.expiryDays}
                onChange={e => handleInputChange('expiryDays', Number(e.target.value))}
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={handleExpirySave}>Set Expiry</Button>
          </CardFooter>
        </Card>
      </div>
    </AdminWrapper>
  );
}
