import AdminDashboardPage from './dashboard/page';

export default function AdminPage() {
  return <AdminDashboardPage />;
}
