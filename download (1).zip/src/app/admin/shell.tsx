
'use client';

import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarTrigger,
} from '@/components/ui/sidebar';
import { AdminNav } from '@/components/AdminNav';
import { useSettings } from '@/hooks/useSettings';
import { Logo } from '@/components/Logo';

export function AdminShell({ children }: { children: React.ReactNode }) {
  const { settings } = useSettings();

  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarContent>
          <AdminNav />
        </SidebarContent>
        <SidebarFooter>
          <AdminNav isFooter={true} />
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
        <header className="sticky top-0 z-40 flex h-14 items-center justify-between border-b bg-background px-4 sm:hidden">
          <SidebarTrigger />
        </header>
        <div className="flex-1 overflow-auto p-4 lg:p-6">{children}</div>
      </SidebarInset>
    </SidebarProvider>
  );
}
