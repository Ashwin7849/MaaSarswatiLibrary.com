'use client';

import { useState, useMemo } from 'react';
import { useUser } from '@/hooks/useUser';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Check, X } from 'lucide-react';
import type { Seat } from '@/lib/seats';
import { AdminWrapper } from '../admin-wrapper';
import Image from 'next/image';

export default function PaymentVerificationPage() {
  const { seats, users, updateSeatPaymentStatus } = useUser();
  const { toast } = useToast();
  const [selectedBooking, setSelectedBooking] = useState<Seat | null>(null);
  const [isApproveDialogOpen, setIsApproveDialogOpen] = useState(false);
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [isImageViewerOpen, setIsImageViewerOpen] = useState(false);
  const [rejectionComment, setRejectionComment] = useState('');

  const pendingVerificationBookings = useMemo(
    () =>
      seats.filter(
        (seat) =>
          seat.status === 'pending' &&
          seat.payment?.status === 'pending_verification'
      ),
    [seats]
  );

  const getUserInfo = (userId: string | null) => {
    if (!userId) return { name: 'Unknown', phone: 'N/A' };
    const bookingUser = users.find((u) => u.id === userId);
    return {
      name: bookingUser?.name || 'Unknown User',
      phone: bookingUser?.phone || 'N/A',
    };
  };

  const handleApprove = (booking: Seat) => {
    setSelectedBooking(booking);
    setIsApproveDialogOpen(true);
  };

  const handleReject = (booking: Seat) => {
    setSelectedBooking(booking);
    setRejectionComment('');
    setIsRejectDialogOpen(true);
  };

  const confirmApprove = () => {
    if (!selectedBooking) return;
    updateSeatPaymentStatus(selectedBooking.id, 'verified');
    toast({
      title: 'Payment Approved',
      description: `Booking for seat ${selectedBooking.number} is now confirmed.`,
    });
    setIsApproveDialogOpen(false);
    setSelectedBooking(null);
  };

  const confirmReject = () => {
    if (!selectedBooking) return;
    updateSeatPaymentStatus(
      selectedBooking.id,
      'rejected',
      rejectionComment
    );
    toast({
      title: 'Payment Rejected',
      description: `Booking for seat ${selectedBooking.number} has been rejected.`,
    });
    setIsRejectDialogOpen(false);
    setSelectedBooking(null);
  };

  const viewScreenshot = (booking: Seat) => {
    setSelectedBooking(booking);
    setIsImageViewerOpen(true);
  };

  return (
    <AdminWrapper>
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-3xl font-bold font-headline">
            Payment Verification
          </h1>
          <p className="text-muted-foreground">
            Approve or reject pending booking payments.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Pending Verifications</CardTitle>
            <CardDescription>
              The following bookings are awaiting payment verification.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {pendingVerificationBookings.length > 0 ? (
              <div className="w-full overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Seat</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Transaction ID</TableHead>
                      <TableHead>Screenshot</TableHead>
                      <TableHead>Uploaded At</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingVerificationBookings.map((seat) => {
                      const userInfo = getUserInfo(seat.userId);
                      const uploadedAt = seat.payment?.uploadedAt
                        ? new Date(seat.payment.uploadedAt)
                        : null;
                      return (
                        <TableRow key={seat.id}>
                          <TableCell className="font-medium">
                            {seat.number}
                          </TableCell>
                          <TableCell>
                            {userInfo.name} ({userInfo.phone})
                          </TableCell>
                           <TableCell>
                            {seat.payment?.transactionId || 'N/A'}
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => viewScreenshot(seat)}
                              disabled={!seat.payment?.screenshotPath}
                            >
                              View
                            </Button>
                          </TableCell>
                           <TableCell>
                            {uploadedAt ? uploadedAt.toLocaleString() : 'N/A'}
                          </TableCell>
                          <TableCell className="text-right space-x-2">
                             <Button
                              variant="ghost"
                              size="icon"
                              className="text-green-600 hover:text-green-700"
                              onClick={() => handleApprove(seat)}
                            >
                              <Check className="h-5 w-5" />
                            </Button>
                             <Button
                              variant="ghost"
                              size="icon"
                              className="text-red-600 hover:text-red-700"
                              onClick={() => handleReject(seat)}
                            >
                              <X className="h-5 w-5" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <p className="py-8 text-center text-muted-foreground">
                No payments are currently pending verification.
              </p>
            )}
          </CardContent>
        </Card>

        {/* Approve Dialog */}
        <AlertDialog
          open={isApproveDialogOpen}
          onOpenChange={setIsApproveDialogOpen}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Approve Payment?</AlertDialogTitle>
              <AlertDialogDescription>
                This will confirm the booking for seat {selectedBooking?.number}.
                The user will be notified. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={confirmApprove}>
                Confirm Approval
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Reject Dialog */}
         <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Reject Payment?</DialogTitle>
              <DialogDescription>
                This will reject the booking for seat {selectedBooking?.number}.
                The seat will become available again. Provide an optional reason.
              </DialogDescription>
            </DialogHeader>
             <div className="py-4">
              <Textarea
                placeholder="Reason for rejection (e.g., screenshot unclear)..."
                value={rejectionComment}
                onChange={(e) => setRejectionComment(e.target.value)}
              />
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsRejectDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button variant="destructive" onClick={confirmReject}>
                Confirm Rejection
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>


        {/* Screenshot Viewer */}
        <Dialog open={isImageViewerOpen} onOpenChange={setIsImageViewerOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>
                Payment Screenshot for Seat {selectedBooking?.number}
              </DialogTitle>
            </DialogHeader>
            {selectedBooking?.payment?.screenshotPath && (
              <div className="relative h-[70vh]">
                <Image
                  src={selectedBooking.payment.screenshotPath}
                  alt="Payment Screenshot"
                  layout="fill"
                  objectFit="contain"
                />
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AdminWrapper>
  );
}
