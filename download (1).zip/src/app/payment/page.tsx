
'use client';

import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useUser } from '@/hooks/useUser';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Upload } from 'lucide-react';
import Image from 'next/image';
import { useSettings } from '@/hooks/useSettings';

export default function PaymentPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user, seats, uploadPaymentProof } = useUser();
  const { settings } = useSettings();
  const { toast } = useToast();

  const [seatId, setSeatId] = useState<string | null>(null);
  const [seatNumber, setSeatNumber] = useState<number | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [transactionId, setTransactionId] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  
  const amount = 500; // Example amount

  useEffect(() => {
    const id = searchParams.get('seatId');
    if (!id) {
      toast({
        variant: 'destructive',
        title: 'Invalid Booking',
        description: 'No seat ID was provided.',
      });
      router.push('/booking');
      return;
    }

    const seat = seats.find((s) => s.id === id);
    if (!seat || seat.userId !== user?.id) {
      toast({
        variant: 'destructive',
        title: 'Booking Not Found',
        description:
          'Could not find the pending booking for your account.',
      });
      router.push('/booking');
      return;
    }

    setSeatId(id);
    setSeatNumber(seat.number);
  }, [searchParams, seats, user, router, toast]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.size > 10 * 1024 * 1024) {
        // 10MB
        toast({
          variant: 'destructive',
          title: 'File Too Large',
          description: 'Please upload a file smaller than 10MB.',
        });
        return;
      }
      if (!['image/jpeg', 'image/png'].includes(selectedFile.type)) {
        toast({
          variant: 'destructive',
          title: 'Invalid File Type',
          description: 'Please upload a JPG or PNG image.',
        });
        return;
      }
      setFile(selectedFile);
      setPreview(URL.createObjectURL(selectedFile));
    }
  };

  const handleSubmit = async () => {
    if (!file || !seatId) {
      toast({
        variant: 'destructive',
        title: 'Missing Information',
        description: 'Please upload a payment screenshot.',
      });
      return;
    }

    setIsUploading(true);
    try {
      await uploadPaymentProof(seatId, file, transactionId);
      toast({
        title: 'Upload Successful',
        description:
          'Your payment proof has been submitted and is pending verification.',
      });
      router.push('/dashboard');
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Upload Failed',
        description:
          error instanceof Error ? error.message : 'An unknown error occurred.',
      });
    } finally {
      setIsUploading(false);
    }
  };

  if (!seatId || !seatNumber) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-2xl py-12">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold font-headline">
            Complete Your Booking
          </CardTitle>
          <CardDescription>
            Pay ₹{amount} for Seat {seatNumber} and upload proof of payment.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <div className="space-y-2">
              <Label>Scan QR Code</Label>
              <div className="p-4 border rounded-md flex justify-center">
                {settings.qrCode && (
                  <Image
                    src={settings.qrCode}
                    alt="Payment QR Code"
                    width={150}
                    height={150}
                  />
                )}
              </div>
            </div>
            <div className="space-y-4 text-center md:text-left">
                <p className="text-muted-foreground">Or pay using UPI ID:</p>
                <p className="font-mono text-lg font-bold bg-muted p-3 rounded-md">
                  {settings.upiId}
                </p>
                <Button onClick={() => navigator.clipboard.writeText(settings.upiId)}>
                    Copy UPI ID
                </Button>
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="transactionId">
              Transaction ID (Optional)
            </Label>
            <Input
              id="transactionId"
              placeholder="Enter your transaction or reference ID"
              value={transactionId}
              onChange={(e) => setTransactionId(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="screenshot">Upload Payment Screenshot</Label>
            <Input id="screenshot" type="file" accept="image/png, image/jpeg" onChange={handleFileChange} />
            <p className="text-xs text-muted-foreground">Max 10MB, JPG/PNG only.</p>
          </div>
          
          {preview && (
            <div>
              <Label>Screenshot Preview</Label>
              <div className="mt-2 relative w-full h-64 border rounded-md">
                  <Image src={preview} alt="Screenshot preview" layout="fill" objectFit="contain" />
              </div>
            </div>
          )}

        </CardContent>
        <CardFooter>
          <Button
            className="w-full"
            onClick={handleSubmit}
            disabled={!file || isUploading}
          >
            {isUploading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Upload className="mr-2 h-4 w-4" />
            )}
            Submit for Verification
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
