
export type Language = 'en' | 'hi';

const common = {
  libraryName: 'Maa Saraswati Library',
  librarySlogan: 'Read Today, Lead Tomorrow.',
};

const en = {
  ...common,
  header: {
    home: 'Home',
    myBooking: 'My Booking',
    settings: 'Settings',
    hindi: 'Hindi',
    english: 'English',
    help: 'Help',
    logout: 'Logout',
  },
  login: {
    logoAlt: 'Library Logo',
    usernamePlaceholder: 'Username',
    passwordPlaceholder: 'Password',
    phonePlaceholder: 'Phone Number',
    loginButton: 'LOGIN',
    forgotPassword: 'Forgot password',
    noAccount: "I haven't account?",
    createAccount: 'Create Account',
  },
  booking: {
    pleaseLogIn: 'Please Log In',
    logInToBook: 'You need to be logged in to book a seat.',
    goToLogin: 'Go to Login',
    totalSeatsCard: {
      title: 'Total Seats',
      description: 'Total capacity',
    },
    selectedCard: {
      title: 'Selected',
      description: 'Your choice',
    }
  },
  busLayout: {
    selectSeat: 'Select Seat',
    specialSeats: 'Special Seats',
    seatStatusTitle: 'Seat Status',
    status: {
      available: { en: 'Available', hi: 'उपलब्ध' },
      booked: { en: 'Booked', hi: 'बुक्ड' },
      selected: { en: 'Selected', hi: 'चयनित' },
      yourSeat: { en: 'Your Seat', hi: 'आपकी सीट' },
    },
    updateBooking: 'Update Booking',
    confirmBooking: 'Confirm Booking for Seat {seatNumber}',
  },
  myBooking: {
    loading: 'Loading Your Booking...',
    noBooking: {
      title: 'No Active Booking',
      description: "You haven't booked a seat yet.",
      button: 'Book a Seat',
    },
    bookedSeat: {
      title: 'Your Booked Seat',
      description: 'This is your currently active booking.',
      seatLocation: 'Row {row}, Seat {number}',
      studySpot: 'Your designated study spot.',
      bookedOn: 'Booked on',
      expiresOn: 'Expires on',
    },
    cancelBookingButton: 'Cancel Booking',
    cancelDialog: {
      title: 'Are you sure?',
      description: 'This action will cancel your booking and make the seat available for others. You cannot undo this.',
      keepButton: 'Keep Booking',
      confirmButton: 'Confirm Cancellation',
    }
  },
  toasts: {
    seatUnavailable: 'Seat unavailable',
    seatAlreadyBooked: 'This seat is already booked.',
    seatUnderMaintenance: 'This seat is currently under maintenance.',
    alreadyHaveBooking: 'You have already booked a seat.',
    bookingConfirmed: {
      title: 'Booking Confirmed!',
      description: 'You have successfully booked seat {seatNumber}.',
      bookedOn: 'Booked on',
      expiresOn: 'Expires on',
    },
    bookingCancelled: {
        title: 'Booking Cancelled',
        description: 'Your seat has been successfully cancelled.',
    },
    error: {
      title: 'An error occurred',
      description: 'Please try again.',
    }
  }
};

const hi = {
  ...common,
  header: {
    home: 'होम',
    myBooking: 'मेरा बुकिंग',
    settings: 'सेटिंग्स',
    hindi: 'हिंदी',
    english: 'English',
    help: 'सहायता',
    logout: 'लॉग आउट',
  },
  login: {
    logoAlt: 'लाइब्रेरी लोगो',
    usernamePlaceholder: 'उपयोगकर्ता नाम',
    passwordPlaceholder: 'पासवर्ड',
    phonePlaceholder: 'फ़ोन नंबर',
    loginButton: 'लॉग इन करें',
    forgotPassword: 'पासवर्ड भूल गए',
    noAccount: 'मेरा खाता नहीं है?',
    createAccount: 'खाता बनाएं',
  },
   booking: {
    pleaseLogIn: 'कृपया लॉग इन करें',
    logInToBook: 'सीट बुक करने के लिए आपको लॉग इन होना आवश्यक है।',
    goToLogin: 'लॉगिन पेज पर जाएं',
    totalSeatsCard: {
      title: 'कुल सीट',
      description: 'कुल क्षमता',
    },
    selectedCard: {
      title: 'चयनित',
      description: 'आपकी पसंद',
    }
  },
  busLayout: {
    selectSeat: 'सीट चुनें',
    specialSeats: 'विशेष सीट',
    seatStatusTitle: 'सीट स्थिति',
    status: {
      available: { en: 'Available', hi: 'उपलब्ध' },
      booked: { en: 'Booked', hi: 'बुक्ड' },
      selected: { en: 'Selected', hi: 'चयनित' },
      yourSeat: { en: 'Your Seat', hi: 'आपकी सीट' },
    },
    updateBooking: 'बुकिंग अपडेट करें',
    confirmBooking: 'सीट {seatNumber} के लिए बुकिंग की पुष्टि करें',
  },
   myBooking: {
    loading: 'आपकी बुकिंग लोड हो रही है...',
    noBooking: {
      title: 'कोई सक्रिय बुकिंग नहीं है',
      description: 'आपने अभी तक कोई सीट बुक नहीं की है।',
      button: 'एक सीट बुक करें',
    },
    bookedSeat: {
      title: 'आपकी बुक की गई सीट',
      description: 'यह आपकी वर्तमान में सक्रिय बुकिंग है।',
      seatLocation: 'पंक्ति {row}, सीट {number}',
      studySpot: 'आपका निर्धारित अध्ययन स्थान।',
      bookedOn: 'बुक करने की तारीख',
      expiresOn: 'समाप्ति तिथी',
    },
    cancelBookingButton: 'बुकिंग रद्द करें',
    cancelDialog: {
      title: 'क्या आप निश्चित हैं?',
      description: 'यह कार्रवाई आपकी बुकिंग रद्द कर देगी और सीट दूसरों के लिए उपलब्ध करा देगी। आप इसे पूर्ववत नहीं कर सकते।',
      keepButton: 'बुकिंग रखें',
      confirmButton: 'रद्दीकरण की पुष्टि करें',
    }
  },
  toasts: {
    seatUnavailable: 'सीट अनुपलब्ध',
    seatAlreadyBooked: 'यह सीट पहले से ही बुक है।',
    seatUnderMaintenance: 'यह सीट वर्तमान में रखरखाव में है।',
    alreadyHaveBooking: 'आप पहले ही एक सीट बुक कर चुके हैं।',
    bookingConfirmed: {
      title: 'बुकिंग की पुष्टि हुई!',
      description: 'आपने सफलतापूर्वक सीट {seatNumber} बुक कर ली है।',
      bookedOn: 'बुक करने की तारीख',
      expiresOn: 'समाप्ति तिथी',
    },
    bookingCancelled: {
        title: 'बुकिंग रद्द!',
        description: 'आपकी सीट सफलतापूर्वक रद्द कर दी गई है।',
    },
    error: {
      title: 'एक त्रुटि हुई',
      description: 'कृपया पुनः प्रयास करें।',
    }
  }
};

export const translations = { en, hi };
export type Translations = typeof translations;
