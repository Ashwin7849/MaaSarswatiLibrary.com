
'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { LogOut, Menu, Settings, HelpCircle, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useUser } from '@/hooks/useUser';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetClose,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { Logo } from './Logo';
import { useState, useEffect } from 'react';
import { useLanguage } from '@/hooks/useLanguage';
import type { Language } from '@/lib/translations';
import { useSettings } from '@/hooks/useSettings';

export function Header() {
  const pathname = usePathname();
  const { user, logout } = useUser();
  const { settings } = useSettings();
  const router = useRouter();
  const { t, setLanguage, language } = useLanguage();
  const [hasMounted, setHasMounted] = useState(false);

  useEffect(() => {
    setHasMounted(true);
  }, []);

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
  };

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  if (!hasMounted) {
    // Avoid rendering on the server to prevent hydration mismatch
    return (
       <header className="sticky top-0 z-50 w-full border-b bg-primary text-primary-foreground shadow-md">
        <div className="container flex h-16 items-center justify-between">
          {/* Skeleton or placeholder content */}
        </div>
      </header>
    );
  }


  if (pathname === '/login' || pathname.startsWith('/admin') || pathname === '/register') {
    return null;
  }

  const handleHelpRedirect = () => {
    // Replace with your actual WhatsApp number
    window.open('https://wa.me/917849875862', '_blank');
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-primary text-primary-foreground shadow-md">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="flex w-full max-w-xs flex-col p-0">
              <SheetHeader className="border-b p-4 text-left">
                <SheetTitle>
                  <div className="flex items-center gap-3">
                    {settings.logo ? (
                      <img src={settings.logo} alt={t.login.logoAlt} className="h-12 w-12 rounded-full" />
                    ) : (
                      <Logo className="h-12 w-12" />
                    )}
                    <div className="flex flex-col">
                      <h1 className="text-xl font-bold font-headline tracking-wider">
                        {settings.libraryName}
                      </h1>
                    </div>
                  </div>
                </SheetTitle>
              </SheetHeader>
              <div className="flex flex-1 flex-col justify-between overflow-y-auto">
                <div className="flex flex-col p-4 space-y-2">
                   <SheetClose asChild>
                      <Link href="/booking">
                        <Button
                          variant={pathname === '/booking' ? 'secondary' : 'ghost'}
                          className="w-full justify-start text-base"
                        >
                          {t.header.home}
                        </Button>
                      </Link>
                    </SheetClose>
                     <SheetClose asChild>
                      <Link href="/dashboard">
                        <Button
                          variant={pathname === '/dashboard' ? 'secondary' : 'ghost'}
                          className="w-full justify-start text-base"
                        >
                           {t.header.myBooking}
                        </Button>
                      </Link>
                    </SheetClose>

                  <Separator className="my-2" />

                  <Collapsible>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" className="w-full justify-between text-base">
                        <div className="flex items-center gap-2">
                          <Settings />
                          <span>{t.header.settings}</span>
                        </div>
                        <ChevronDown className="h-4 w-4" />
                      </Button>
                    </CollapsibleTrigger>
                    <CollapsibleContent className="space-y-1 py-1 pl-8">
                       <SheetClose asChild>
                         <Button variant={language === 'hi' ? 'secondary' : 'ghost'} className="w-full justify-start text-sm" onClick={() => handleLanguageChange('hi')}>{t.header.hindi}</Button>
                       </SheetClose>
                       <SheetClose asChild>
                        <Button variant={language === 'en' ? 'secondary' : 'ghost'} className="w-full justify-start text-sm" onClick={() => handleLanguageChange('en')}>{t.header.english}</Button>
                       </SheetClose>
                    </CollapsibleContent>
                  </Collapsible>
                  
                   <SheetClose asChild>
                     <Button variant="ghost" className="w-full justify-start text-base gap-2" onClick={handleHelpRedirect}>
                        <HelpCircle />
                        {t.header.help}
                     </Button>
                  </SheetClose>


                </div>

                <div className="border-t p-4">
                  <SheetClose asChild>
                    <Button
                      variant="destructive"
                      className="w-full justify-center gap-2"
                      onClick={handleLogout}
                    >
                      <LogOut className="h-5 w-5" />
                      <span>{t.header.logout}</span>
                    </Button>
                  </SheetClose>
                </div>
              </div>
            </SheetContent>
          </Sheet>

          <div className="flex items-center gap-3">
             <Link href="/booking">
                {settings.logo ? (
                  <img src={settings.logo} alt={t.login.logoAlt} className="h-10 w-10 rounded-full" />
                ) : (
                  <Logo className="h-10 w-10" />
                )}
             </Link>
             <div className="flex flex-col">
              <h1 className="text-lg font-bold font-headline tracking-wider">
                {settings.libraryName}
              </h1>
              <p className="text-xs">Hi, {user?.name}</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
