
'use client';

import {
  SidebarMenuItem,
  SidebarMenuButton,
} from '@/components/ui/sidebar';
import {
  SheetClose,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet';
import {
  LayoutDashboard,
  Users,
  Armchair,
  Settings,
  LogOut,
  Book,
  CreditCard,
} from 'lucide-react';
import { useUser } from '@/hooks/useUser';
import { usePathname, useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import Link from 'next/link';
import { useIsMobile } from '@/hooks/use-mobile';
import { Logo } from './Logo';
import { useMemo } from 'react';
import { useSettings } from '@/hooks/useSettings';

export function AdminNav({ isFooter = false }: { isFooter?: boolean }) {
  const { user, logout } = useUser();
  const { settings } = useSettings();
  const router = useRouter();
  const pathname = usePathname();
  const isMobile = useIsMobile();

  const handleLogout = () => {
    logout();
    router.push('/login');
  };

  const navLinks = useMemo(
    () => [
      { href: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { href: '/admin/bookings', label: 'All Bookings', icon: Book },
      { href: '/admin/payments', label: 'Payments', icon: CreditCard },
      { href: '/admin/users', label: 'User Management', icon: Users },
      { href: '/admin/seats', label: 'Seat Management', icon: Armchair },
      { href: '/admin/settings', label: 'Settings', icon: Settings },
    ],
    []
  );

  const menuContent = useMemo(
    () => (
      <>
        {navLinks.map(link => (
          <SidebarMenuItem key={link.href}>
            <Link href={link.href} className="w-full" passHref legacyBehavior>
              <SidebarMenuButton
                as="a"
                isActive={pathname.startsWith(link.href)}
                tooltip={{ children: link.label }}
              >
                <link.icon />
                <span>{link.label}</span>
              </SidebarMenuButton>
            </Link>
          </SidebarMenuItem>
        ))}
      </>
    ),
    [navLinks, pathname]
  );

  if (isFooter) {
    return (
      <>
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8">
            <AvatarFallback>{user?.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex flex-col">
            <span className="text-sm font-semibold">{user?.name}</span>
            <span className="text-xs text-muted-foreground">Admin</span>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="ml-auto"
          onClick={handleLogout}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
      </>
    );
  }

  if (isMobile) {
    return (
      <>
        <SheetHeader className="border-b p-4 text-left">
          <SheetTitle>
            <div className="flex items-center gap-3">
              {settings.logo ? (
                <img
                  src={settings.logo}
                  alt="Library Logo"
                  className="h-8 w-8 rounded-full"
                />
              ) : (
                <Logo className="h-8 w-8" />
              )}
              <span>Admin Menu</span>
            </div>
          </SheetTitle>
          <SheetDescription>
            Navigation links for the admin panel.
          </SheetDescription>
        </SheetHeader>
        <div className="flex flex-col p-2">
          {navLinks.map(link => (
            <SheetClose asChild key={link.href}>
              <SidebarMenuItem>
                <Link href={link.href} className="w-full" passHref legacyBehavior>
                  <SidebarMenuButton
                    as="a"
                    isActive={pathname.startsWith(link.href)}
                    tooltip={{ children: link.label }}
                  >
                    <link.icon />
                    <span>{link.label}</span>
                  </SidebarMenuButton>
                </Link>
              </SidebarMenuItem>
            </SheetClose>
          ))}
        </div>
      </>
    );
  }

  return <div className="flex flex-col p-2">{menuContent}</div>;
}
