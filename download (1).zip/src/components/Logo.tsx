export function Logo({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 200 200"
      xmlns="http://www.w3.org/2000/svg"
      width="100"
      height="100"
    >
      <defs>
        <path
          id="circlePathTop"
          d="M 50,100 A 50,50 0 1 1 150,100"
          fill="none"
        />
        <path
          id="circlePathBottom"
          d="M 50,100 A 50,50 0 0 0 150,100"
          fill="none"
        />
      </defs>

      {/* Outer circle */}
      <circle cx="100" cy="100" r="98" fill="white" />
      <circle cx="100" cy="100" r="95" fill="#007bff" />
      <circle cx="100" cy="100" r="80" fill="white" />

      {/* Inner blue circle for text background */}
      <circle cx="100" cy="100" r="78" fill="#007bff" />

      {/* White banner */}
      <rect x="25" y="85" width="150" height="30" fill="white" />

      {/* Text */}
      <text
        fill="white"
        fontSize="24"
        fontWeight="bold"
        fontFamily="Arial, sans-serif"
        letterSpacing="2"
      >
        <textPath href="#circlePathTop" startOffset="50%" textAnchor="middle">
          MAA SARSWATI
        </textPath>
      </text>
      <text
        fill="white"
        fontSize="24"
        fontWeight="bold"
        fontFamily="Arial, sans-serif"
        letterSpacing="2"
      >
        <textPath
          href="#circlePathBottom"
          startOffset="50%"
          textAnchor="middle"
        >
          LIBRARY
        </textPath>
      </text>

      {/* Book Icon */}
      <g transform="translate(80 82) scale(0.4)">
        <path
          d="M45.5,2.7H7.5C5,2.7,3,4.7,3,7.2v35.6c0,2.5,2,4.5,4.5,4.5h38.1c2.5,0,4.5-2,4.5-4.5V7.2C50,4.7,48,2.7,45.5,2.7z M8.4,43.4c-0.3,0-0.6-0.1-0.8-0.3c-0.2-0.2-0.3-0.5-0.3-0.8V7.2C7.3,6.1,8,5.4,9,5.4h34.1c1,0,1.8,0.7,1.8,1.8v35.1c0,1-0.8,1.8-1.8,1.8H9C8.8,44.1,8.6,43.8,8.4,43.4z"
          fill="#007bff"
        />
        <path
          d="M26.5,8.1H12.4c-0.5,0-0.9,0.4-0.9,0.9s0.4,0.9,0.9,0.9h14.1c0.5,0,0.9-0.4,0.9-0.9S27,8.1,26.5,8.1z"
          fill="#007bff"
        />
        <path
          d="M37.6,13.1H12.4c-0.5,0-0.9,0.4-0.9,0.9s0.4,0.9,0.9,0.9h25.2c0.5,0,0.9-0.4,0.9-0.9S38.1,13.1,37.6,13.1z"
          fill="#007bff"
        />
        <path
          d="M37.6,18.1H12.4c-0.5,0-0.9,0.4-0.9,0.9s0.4,0.9,0.9,0.9h25.2c0.5,0,0.9-0.4,0.9-0.9S38.1,18.1,37.6,18.1z"
          fill="#007bff"
        />
        <path
          d="M37.6,23.1H12.4c-0.5,0-0.9,0.4-0.9,0.9s0.4,0.9,0.9,0.9h25.2c0.5,0,0.9-0.4,0.9-0.9S38.1,23.1,37.6,23.1z"
          fill="#007bff"
        />
         <path
          d="M37.6,28.1H12.4c-0.5,0-0.9,0.4-0.9,0.9s0.4,0.9,0.9,0.9h25.2c0.5,0,0.9-0.4,0.9-0.9S38.1,28.1,37.6,28.1z"
          fill="#007bff"
        />
         <path
          d="M37.6,33.1H12.4c-0.5,0-0.9,0.4-0.9,0.9s0.4,0.9,0.9,0.9h25.2c0.5-0,0.9-0.4,0.9-0.9S38.1,33.1,37.6,33.1z"
          fill="#007bff"
        />
         <path
          d="M26.5,38.1H12.4c-0.5,0-0.9,0.4-0.9,0.9s0.4,0.9,0.9,0.9h14.1c0.5-0,0.9-0.4,0.9-0.9S27,38.1,26.5,38.1z"
          fill="#007bff"
        />
      </g>

      {/* Laurels */}
      <g transform="translate(68 94) scale(0.3) rotate(-15)">
        <path d="M0,0 C10,-20 30,-20 40,0" fill="none" stroke="#007bff" strokeWidth="5"/>
        <path d="M5,5 C15,-15 35,-15 45,5" fill="none" stroke="#007bff" strokeWidth="5"/>
        <path d="M10,10 C20,-10 40,-10 50,10" fill="none" stroke="#007bff" strokeWidth="5"/>
        <path d="M15,15 C25,-5 45,-5 55,15" fill="none" stroke="#007bff" strokeWidth="5"/>
      </g>
      <g transform="translate(132 94) scale(-0.3, 0.3) rotate(-15)">
        <path d="M0,0 C10,-20 30,-20 40,0" fill="none" stroke="#007bff" strokeWidth="5"/>
        <path d="M5,5 C15,-15 35,-15 45,5" fill="none" stroke="#007bff" strokeWidth="5"/>
        <path d="M10,10 C20,-10 40,-10 50,10" fill="none" stroke="#007bff" strokeWidth="5"/>
        <path d="M15,15 C25,-5 45,-5 55,15" fill="none" stroke="#007bff" strokeWidth="5"/>
      </g>
    </svg>
  );
}
