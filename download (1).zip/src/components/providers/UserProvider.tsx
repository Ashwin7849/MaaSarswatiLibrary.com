
'use client';

import {
  createContext,
  useState,
  useEffect,
  type ReactNode,
  useCallback,
  useMemo,
} from 'react';
import { initialSeats, type Seat } from '@/lib/seats';
import { useToast } from '@/hooks/use-toast';

type User = {
  id: string;
  name: string;
  phone: string;
  role: 'user' | 'admin';
};

type UserContextType = {
  user: User | null;
  users: User[];
  seats: Seat[];
  userBooking: Seat | undefined;
  seatStats: { total: number; booked: number; available: number; blocked: number, pending: number };
  isLoading: boolean;
  login: (name: string, phone: string) => User;
  registerUser: (name: string, phone: string) => User;
  logout: () => void;
  bookSeat: (seatId: string) => Promise<Seat>;
  cancelBooking: (seatId: string) => void;
  updateSeatStatus: (seatId: string, status: Seat['status']) => void;
  uploadPaymentProof: (seatId: string, file: File, transactionId?: string) => Promise<void>;
  updateSeatPaymentStatus: (seatId: string, status: 'verified' | 'rejected', adminComment?: string) => void;
};

export const UserContext = createContext<UserContextType | undefined>(
  undefined
);

const defaultUsers: User[] = [
  {id: 'student-1234567890', name: 'Student', phone: '1234567890', role: 'user'},
  {id: 'admin-special-id', name: 'Ashwin', phone: 'Ashu000', role: 'admin'}
];

const loadUsersFromStorage = (): User[] => {
  if (typeof window === 'undefined') return defaultUsers;
  try {
    const storedUsers = localStorage.getItem('seatwise_users');
    if (!storedUsers) {
      localStorage.setItem('seatwise_users', JSON.stringify(defaultUsers));
      return defaultUsers;
    }
    return JSON.parse(storedUsers);
  } catch (e) {
    return defaultUsers;
  }
};

const saveUsersToStorage = (users: User[]) => {
  if (typeof window !== 'undefined') {
    localStorage.setItem('seatwise_users', JSON.stringify(users));
  }
};

const loadSeatsFromStorage = (): Seat[] => {
    if (typeof window === 'undefined') return initialSeats;
    try {
        const storedSeats = localStorage.getItem('seatwise_seats');
        return storedSeats ? JSON.parse(storedSeats) : initialSeats;
    } catch(e) {
        return initialSeats;
    }
}

const saveSeatsToStorage = (seats: Seat[]) => {
    if(typeof window !== 'undefined') {
        localStorage.setItem('seatwise_seats', JSON.stringify(seats));
    }
}


export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [seats, setSeats] = useState<Seat[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

   useEffect(() => {
    setIsLoading(true);
    try {
      const storedUser = localStorage.getItem('seatwise_user');
       if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
      setUsers(loadUsersFromStorage());
      setSeats(loadSeatsFromStorage());
    } catch (error) {
      console.error('Failed to parse from localStorage', error);
      localStorage.clear(); 
      setUsers(loadUsersFromStorage());
      setSeats(loadSeatsFromStorage());
    } finally {
      setIsLoading(false);
    }
  }, []);


  const login = useCallback(
    (name: string, phone: string) => {
      if (name === 'Ashwin123' && phone === 'Ashu000') {
        const adminUser: User = {
          id: 'admin-special-id',
          name: 'Ashwin',
          phone: '0000000000',
          role: 'admin',
        };
        setUser(adminUser);
        localStorage.setItem('seatwise_user', JSON.stringify(adminUser));
        toast({
          title: `Welcome, Admin!`,
          description: 'You have successfully logged in.',
        });
        return adminUser;
      }
      
      const existingUser = users.find(
        (u) => u.name === name && u.phone === phone
      );

      if (existingUser) {
        setUser(existingUser);
        localStorage.setItem('seatwise_user', JSON.stringify(existingUser));
        toast({
          title: `Welcome back, ${name}!`,
          description: 'You have successfully logged in.',
        });
        return existingUser;
      }

      throw new Error('Invalid credentials. Please check your username and phone number.');
    },
    [toast, users]
  );
  
  const registerUser = useCallback(
    (name: string, phone: string) => {
      const userExists = users.some((u) => u.phone === phone);
      if (userExists) {
        throw new Error('A user with this phone number already exists.');
      }
      
      const newUser: User = {
        id: `user-${Date.now()}`,
        name,
        phone,
        role: 'user',
      };
      
      const updatedUsers = [...users, newUser];
      setUsers(updatedUsers);
      saveUsersToStorage(updatedUsers);

      toast({
        title: 'Registration Successful',
        description: `Welcome, ${name}! You can now log in.`,
      });

      return newUser;
    },
    [users, toast]
  );


  const logout = useCallback(() => {
    const userName = user?.name;
    setUser(null);
     if (typeof window !== 'undefined') {
        localStorage.removeItem('seatwise_user');
     }
    toast({
      title: `Goodbye, ${userName}!`,
      description: 'You have been logged out.',
    });
  }, [user, toast]);

  const bookSeat = useCallback(
    async (seatId: string) => {
      if (!user) {
        throw new Error('You must be logged in to book a seat.');
      }

      const hasExistingBooking = seats.some(
        seat => seat.userId === user.id && seat.status !== 'available'
      );

      if (hasExistingBooking) {
        throw new Error('You already have an active or pending booking.');
      }

      let newBooking: Seat | undefined;
      const updatedSeats = seats.map(seat => {
        if (seat.id === seatId) {
          newBooking = {
            ...seat,
            status: 'pending',
            userId: user.id,
            bookingDate: Date.now(),
            payment: {
                status: 'pending_verification'
            }
          };
          return newBooking;
        }
        return seat;
      });

      setSeats(updatedSeats);
      saveSeatsToStorage(updatedSeats);

      if (!newBooking) {
        throw new Error('Failed to create booking.');
      }
      return newBooking;
    },
    [user, seats]
  );

  const uploadPaymentProof = useCallback(
    async (seatId: string, file: File, transactionId?: string) => {
      if (!user) throw new Error('Not authenticated');

      const reader = new FileReader();
      const fileAsDataURL = await new Promise<string>((resolve) => {
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
      });
      
      const screenshotPath = fileAsDataURL; 

      const updatedSeats = seats.map((seat) => {
        if (seat.id === seatId && seat.userId === user.id) {
          return {
            ...seat,
            payment: {
              ...seat.payment,
              status: 'pending_verification',
              screenshotPath,
              transactionId: transactionId || '',
              uploadedAt: Date.now(),
            },
          } as Seat;
        }
        return seat;
      });
      setSeats(updatedSeats);
      saveSeatsToStorage(updatedSeats);
    },
    [user, seats]
  );

  const updateSeatPaymentStatus = useCallback(
    (seatId: string, status: 'verified' | 'rejected', adminComment?: string) => {
      const updatedSeats = seats.map(seat => {
        if (seat.id === seatId) {
          if (status === 'verified') {
            return {
              ...seat,
              status: 'booked',
              payment: {
                ...seat.payment,
                status: 'verified',
                adminComment: adminComment || '',
              },
            } as Seat;
          } else { // rejected
            return {
              ...seat,
              status: 'available',
              userId: null,
              bookingDate: null,
              payment: undefined,
            }
          }
        }
        return seat;
      });
      setSeats(updatedSeats);
      saveSeatsToStorage(updatedSeats);
    },
    [seats]
  );

  const cancelBooking = useCallback(
    (seatId: string) => {
      const updatedSeats = seats.map(seat =>
        seat.id === seatId
          ? {
              ...seat,
              status: 'available' as const,
              userId: null,
              bookingDate: null,
              payment: undefined,
            }
          : seat
      );
      setSeats(updatedSeats);
      saveSeatsToStorage(updatedSeats);
    },
    [seats]
  );
  
  const updateSeatStatus = useCallback(
    (seatId: string, status: Seat['status']) => {
      const updatedSeats = seats.map(seat => {
        if (seat.id === seatId) {
          const isBecomingAvailable = status === 'available';
          return {
            ...seat,
            status,
            userId: isBecomingAvailable || status === 'blocked' ? null : seat.userId,
            bookingDate: isBecomingAvailable || status === 'blocked' ? null : seat.bookingDate,
            payment: status === 'booked' || status === 'pending' ? seat.payment : undefined,
          };
        }
        return seat;
      });
      setSeats(updatedSeats);
      saveSeatsToStorage(updatedSeats);
    },
    [seats]
  );


  const userBooking = useMemo(
    () => seats.find(seat => seat.userId === user?.id),
    [seats, user]
  );

  const seatStats = useMemo(() => {
    return seats.reduce((acc, s) => {
      acc.total++;
      if (s.status === 'booked') acc.booked++;
      else if (s.status === 'blocked') acc.blocked++;
      else if (s.status === 'pending') acc.pending++;
      else if (s.status === 'available') acc.available++;
      return acc;
    }, { total: 0, booked: 0, available: 0, blocked: 0, pending: 0 });
  }, [seats]);

  const value = useMemo(
    () => ({
      user,
      users,
      seats,
      userBooking,
      seatStats,
      isLoading,
      login,
      registerUser,
      logout,
      bookSeat,
      cancelBooking,
      updateSeatStatus,
      uploadPaymentProof,
      updateSeatPaymentStatus
    }),
    [
      user,
      users,
      seats,
      userBooking,
      seatStats,
      isLoading,
      login,
      registerUser,
      logout,
      bookSeat,
      cancelBooking,
      updateSeatStatus,
      uploadPaymentProof,
      updateSeatPaymentStatus
    ]
  );

    if (isLoading) {
      return (
        <UserContext.Provider value={value}>
            {null}
        </UserContext.Provider>
      );
    }

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
}
