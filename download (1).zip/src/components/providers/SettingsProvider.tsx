
'use client';

import {
  createContext,
  useState,
  useEffect,
  type ReactNode,
  useMemo,
  useCallback,
} from 'react';

export type Settings = {
  libraryName: string;
  logo: string | null;
  upiId: string;
  qrCode: string | null;
  expiryDays: number;
};

type SettingsContextType = {
  settings: Settings;
  isLoading: boolean;
  saveSettings: (newSettings: Partial<Settings>) => void;
};

export const SettingsContext = createContext<SettingsContextType | undefined>(
  undefined
);

const defaultSettings: Settings = {
  libraryName: 'Maa Saraswati Library',
  logo: null,
  upiId: 'admin-upi@oksbi',
  qrCode: null,
  expiryDays: 31,
};

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    try {
      const storedSettings = localStorage.getItem('seatwise_settings');
      if (storedSettings) {
        const parsedSettings = JSON.parse(storedSettings);
        setSettings((prev) => ({ ...prev, ...parsedSettings }));
      }
    } catch (error) {
      console.error('Failed to load settings from localStorage', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const saveSettings = useCallback((newSettings: Partial<Settings>) => {
    setSettings((prev) => {
      const updatedSettings = { ...prev, ...newSettings };
      try {
        localStorage.setItem(
          'seatwise_settings',
          JSON.stringify(updatedSettings)
        );
      } catch (error) {
        console.error('Failed to save settings to localStorage', error);
      }
      return updatedSettings;
    });
  }, []);

  const value = useMemo(
    () => ({
      settings,
      isLoading,
      saveSettings,
    }),
    [settings, isLoading, saveSettings]
  );
  
  if (isLoading) {
    return (
      <SettingsContext.Provider value={value}>
        {null}
      </SettingsContext.Provider>
    );
  }

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
}
