'use client';

import { useState } from 'react';
import { Armchair } from 'lucide-react';
import { useUser } from '@/hooks/useUser';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Card } from '@/components/ui/card';

export function SeatGrid() {
  const { seats, bookSeat, user } = useUser();
  const [bookingSeatId, setBookingSeatId] = useState<string | null>(null);
  const { toast } = useToast();

  const handleSeatClick = async (seatId: string) => {
    setBookingSeatId(seatId);
    try {
      await bookSeat(seatId);
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'An error occurred',
        description:
          error instanceof Error ? error.message : 'Please try again.',
      });
    } finally {
      setBookingSeatId(null);
    }
  };

  const seatsByRow = seats.reduce((acc, seat) => {
    (acc[seat.row] = acc[seat.row] || []).push(seat);
    return acc;
  }, {} as Record<string, typeof seats>);

  return (
    <Card className="p-4 md:p-8">
      <div className="flex justify-center items-center mb-6 space-x-6">
        <div className="flex items-center">
          <Armchair className="h-5 w-5 text-green-500 mr-2" />
          <span className="text-sm">Available</span>
        </div>
        <div className="flex items-center">
          <Armchair className="h-5 w-5 text-red-500 mr-2" />
          <span className="text-sm">Booked</span>
        </div>
        <div className="flex items-center">
          <Armchair className="h-5 w-5 text-muted-foreground/50 mr-2" />
          <span className="text-sm">Your Booking</span>
        </div>
      </div>

      <div className="space-y-4 overflow-x-auto">
        {Object.entries(seatsByRow).map(([row, seatsInRow]) => (
          <div key={row} className="flex items-center gap-2 md:gap-4">
            <div className="w-8 text-sm font-medium text-muted-foreground">
              Row {row}
            </div>
            <div className="flex-1 grid grid-cols-10 gap-2 md:gap-4">
              {seatsInRow.map((seat, index) => {
                const isAvailable = seat.status === 'available';
                const isMyBooking = seat.userId === user?.id;
                const isBooking = bookingSeatId === seat.id;
                return (
                  <Button
                    key={seat.id}
                    variant="ghost"
                    className={cn(
                      'h-10 w-10 md:h-12 md:w-12 p-0 transition-all duration-200 transform hover:scale-110',
                      isAvailable ? 'text-green-500 hover:text-green-600 hover:bg-green-100' : 'text-red-500 cursor-not-allowed',
                      isMyBooking && 'text-primary bg-primary/20 hover:bg-primary/30',
                      isBooking && 'animate-pulse'
                    )}
                    disabled={!isAvailable || !!bookingSeatId}
                    onClick={() => handleSeatClick(seat.id)}
                    aria-label={`Seat ${seat.row}${seat.number}, ${seat.status}`}
                  >
                    <div className="flex flex-col items-center">
                      <Armchair className="h-6 w-6" />
                      <span className="text-xs font-mono">{seat.number}</span>
                    </div>
                  </Button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
